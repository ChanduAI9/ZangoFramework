# package-frame

How to use frame?
 - Add frame package in your apps
 - Map the route of the frame -
 - Configure frame
 - Add the add_frame_context decorator to class based views and function views