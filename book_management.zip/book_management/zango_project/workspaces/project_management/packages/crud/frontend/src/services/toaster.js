const ZToast = (type, title, message, duration) => {
  $.toast({
    text: `<div class="z-toast-node ${{ error: "z-toast-error", success: "z-toast-success", warning: "z-toast-warning" }[type]}">
                <h3 class="title">
                    ${title}
                </h3>
                <span class="message">
                    ${message}
                </span>
            </div>`,
    hideAfter: duration,
  });

  $(document).find(".jq-toast-single").find(".close-jq-toast-single")
    .html(`<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g id="Icon/Navigation/16px/Close" clip-path="url(#clip0_1917_1245)">
            <path id="Vector" d="M10.5041 0.879019L6.30147 5.08166C6.12945 5.25369 5.85655 5.25369 5.6991 5.08166L1.49588 0.879019C1.32386 0.706994 1.05096 0.706994 0.893507 0.879019C0.721482 1.05104 0.721482 1.32394 0.893507 1.48139L5.09673 5.68461C5.26875 5.85664 5.26875 6.12953 5.09673 6.28699L0.879019 10.5041C0.706994 10.6761 0.706994 10.949 0.879019 11.1065C1.05104 11.2785 1.32394 11.2785 1.48139 11.1065L5.68461 6.90327C5.85664 6.73125 6.12954 6.73125 6.28699 6.90327L10.5041 11.121C10.6761 11.293 10.949 11.293 11.1065 11.121C11.2785 10.949 11.2785 10.6761 11.1065 10.5186L6.91791 6.3009C6.74588 6.12887 6.74588 5.85598 6.91791 5.69853L11.1211 1.49531C11.2932 1.32328 11.2932 1.05038 11.1211 0.892933C10.9491 0.720908 10.6768 0.720908 10.5042 0.878924L10.5041 0.879019Z" fill="#6C747D" stroke="#6C747D" stroke-width="0.4"/>
            </g>
            <defs>
            <clipPath id="clip0_1917_1245">
            <rect width="12" height="12" fill="white"/>
            </clipPath>
            </defs>
            </svg>
        `);
}

export  { ZToast }