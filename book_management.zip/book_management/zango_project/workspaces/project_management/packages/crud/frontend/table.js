import './style.css'
import './src/modules/table/index.js'