export default `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <g id="Frame 122">
                                    <circle id="Ellipse 8" cx="10" cy="16" r="2" transform="rotate(-90 10 16)" fill="currentColor"/>
                                    <circle id="Ellipse 9" cx="10" cy="10" r="2" transform="rotate(-90 10 10)" fill="currentColor"/>
                                    <circle id="Ellipse 10" cx="10" cy="4" r="2" transform="rotate(-90 10 4)" fill="currentColor"/>
                                </g>
                            </svg>`;
