from zango.apps.dynamic_models.models import DynamicModelBase
from django.db import models

class Book(DynamicModelBase):
    AVAILABLE = "available"
    CHECKED_OUT = "checked_out"
    RESERVED = "reserved"
    DAMAGED = "damaged"

    BOOK_STATUS_CHOICES = [
        (AVAILABLE, "Available"),
        (CHECKED_OUT, "Checked Out"),
        (RESERVED, "Reserved"),
        (DAMAGED, "Damaged")
    ]

    title = models.CharField(max_length=150)
    author = models.CharField(max_length=100)
    genre = models.CharField(max_length=50)
    published_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=BOOK_STATUS_CHOICES, default=AVAILABLE)
    added_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.title} by {self.author}"
