from django.urls import path
from .views import BookCrudView

urlpatterns = [
    path('all/', BookCrudView.as_view(), name='book_crud'),
]
