from ..packages.crud.table.base import ModelTable
from ..packages.crud.table.column import ModelCol
from .models import Book
from .forms import BookForm

class BookTable(ModelTable):
    id = ModelCol(display_as='ID', sortable=True, searchable=True)
    title = ModelCol(display_as='Title', sortable=True, searchable=True)
    author = ModelCol(display_as='Author', sortable=True, searchable=True)
    genre = ModelCol(display_as='Genre', sortable=True, searchable=True)
    status = ModelCol(display_as='Status', sortable=True)
    published_date = ModelCol(display_as='Published Date', sortable=True)
    added_at = ModelCol(display_as='Added At', sortable=True)

    table_actions = []
    row_actions = [
        {
            "name": "Edit",
            "key": "edit",
            "description": "Edit Book",
            "type": "form",
            "form": BookForm,
        }
    ]

    class Meta:
        model = Book
        fields = ['id', 'title', 'author', 'genre', 'status', 'published_date', 'added_at']
        row_selector = {'enabled': False, 'multi': False}
