module.exports = function renderDynamicForm(formContainerId, offcanvasId, buttonId, config) {
  // Create the offcanvas HTML structure
  const offcanvasHtml = `
        <div class="offcanvas offcanvas-end" tabindex="-1" id="${offcanvasId}" aria-labelledby="${offcanvasId}Label">
            <div class="offcanvas-content">
                <button type="button" data-bs-dismiss="offcanvas" aria-label="Close" class="modal-close">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                        <g clip-path="url(#clip0_5158_6104)">
                            <path d="M17.7213 1.22117L10.5168 8.42571C10.2219 8.72061 9.75409 8.72061 9.48417 8.42571L2.27865 1.22117C1.98375 0.926275 1.51593 0.926275 1.24601 1.22117C0.951112 1.51607 0.951112 1.9839 1.24601 2.25382L8.45153 9.45933C8.74643 9.75423 8.74643 10.2221 8.45153 10.492L1.22117 17.7213C0.926275 18.0162 0.926275 18.4841 1.22117 18.754C1.51607 19.0489 1.9839 19.0489 2.25382 18.754L9.45933 11.5485C9.75423 11.2536 10.2221 11.2536 10.492 11.5485L17.7213 18.7788C18.0162 19.0737 18.4841 19.0737 18.754 18.7788C19.0489 18.4839 19.0489 18.0161 18.754 17.7462L11.5736 10.5158C11.2787 10.2209 11.2787 9.7531 11.5736 9.48319L18.7791 2.27767C19.074 1.98277 19.074 1.51494 18.7791 1.24503C18.4842 0.950129 18.0173 0.950129 17.7214 1.22101L17.7213 1.22117Z" fill="black" stroke="black" stroke-width="0.4"/>
                        </g>
                        <defs>
                            <clipPath id="clip0_5158_6104">
                                <rect width="20" height="20" fill="white"/>
                            </clipPath>
                        </defs>
                    </svg>
                </button>
                <div id="${formContainerId}" class="zelthy-dynamic-form" style="height: 100%; width: 100%;"></div>
            </div>
        </div>
    `;

  // Append the offcanvas HTML to the body
  $("body").append(offcanvasHtml);

  // Attach the click event to the button to open the offcanvas
  $(`#${buttonId}`).on("click", function () {
    console.log(`${buttonId} clicked`);
    $(`#${offcanvasId} #${formContainerId}`).attr(
      "data-config",
      JSON.stringify(config)
    );
  });

  // Optionally, initialize the offcanvas with Bootstrap if necessary
  var offcanvasElement = document.getElementById(offcanvasId);
  var offcanvasInstance = new bootstrap.Offcanvas(offcanvasElement);
}
